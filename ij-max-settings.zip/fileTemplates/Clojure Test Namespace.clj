(ns $NS_NAME
  (:require
    [clojure.test :refer :all]
    [clojure.spec.alpha :as s]
    [gini.common :refer :all]
    [gini.rmap :as rmap :refer :all :rename {ref $}]
    [ginoco.test-harness :refer :all]
    [ginoco.svc.fake :as fake-svc]
    [medley.core :as medley]
    [matcher-combinators.matchers :as m]
    [matcher-combinators.test :refer :all]
    [$TEST_SUBJECT_NS :as $TEST_SUBJECT_NS]))
